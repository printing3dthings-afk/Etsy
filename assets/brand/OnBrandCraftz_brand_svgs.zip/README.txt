OnBrandCraftz — Brand SVG Pack
==============================
True vector SVGs generated from real font outlines. Not traces.
Each file is one path, one fill, and extrudes watertight.

CONTENTS
--------
  OBC.svg            Montserrat Black    ships 20.00 x 6.29 mm
  OnBrandCraftz.svg  Caveat Bold         ships 80.00 x 12.11 mm

MINIMUM PRINTABLE WIDTH  <- the number that matters
-------------------------------------------------
  OBC.svg              9.4 mm
  OnBrandCraftz.svg   50.5 mm

The rule is 2 extrusions (0.84mm) on the thinnest stroke. Below that the
slicer has less than one bead to work with and the stroke drops out -- the
defect that printed a blank mark on three of four sauce models.

  ** Under ~51mm wide, use OBC instead of the wordmark. **
  That is the whole reason OBC exists.

They scale freely. The shipped size is a starting point; the minimum is not.

USING THEM IN BAMBU STUDIO
--------------------------
  1. Drag the SVG onto the plate (or File > Import).
  2. Set the extrude height -- 0.6mm for a flush inlay, 6-10mm for a sign.
  3. Color Painting (press N) > Fill tool > click each region.
  4. Slice. Verify the AMS slot mapping in the print dialog.

Both carry real mm dimensions with a matching viewBox, so they import at
the size listed above rather than an arbitrary one.

NOT IN THIS PACK, AND WHY
-------------------------
The brush-script shop logo cannot print as an inlay on a P1S at any size
that fits the plate. Its hairline connectors measure 2px on an 1188px-wide
mark (0.168% of the width); reaching 0.84mm would need a 499mm logo, and
the plate is 256mm. Even its median stroke needs 138mm. That logo stays
for listings and the dashboard.

REGENERATE / ADD MORE
---------------------
  python3 tools/text_to_svg.py "TEXT" --font <path.ttf> \
      [--weight 900] --width-mm <N> -o out.svg

Montserrat-Bold.ttf is a VARIABLE font whose default instance is Thin
despite the filename -- pass --weight 900 or the mark comes out thin.

(c) OnBrandCraftz
