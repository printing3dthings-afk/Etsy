OnBrandCraftz — Mom Life Sublimation Tumbler Wrap Bundle
=========================================================
Thank you for your purchase! This ZIP contains 8 JPEG sublimation wrap designs.

FILES INCLUDED
--------------
football_mom_20oz.jpg, cheer_mom_20oz.jpg, dog_mom_20oz.jpg,
nurse_life_20oz.jpg, teacher_life_20oz.jpg, girl_mom_20oz.jpg,
boy_mom_20oz.jpg, mama_mode_20oz.jpg

SPECIFICATIONS
--------------
- Size: 2799 x 2499 pixels (9.33" x 8.33" @ 300 DPI)
- Fits: 20oz Skinny Tumbler
- Format: JPEG, sRGB, 300 DPI — print-ready (JPEG is standard for sublimation)

RESIZING FOR OTHER BLANKS
--------------------------
30oz: 9.5" x 9.1"  |  40oz: 9.5" x 12"  |  11oz mug: 3.8" x 8.5"

LICENSE: Commercial use included for physical finished goods. No digital resale.
Questions: Printing3dthings@outlook.com — © OnBrandCraftz
