Graduation 2026 SVG Bundle — OnBrandCraftz
==========================================

INCLUDED FILES (31 files):
  SVG/ — 10 scalable vector files (800×800 viewBox, scales to any size)
  PNG/ — 10 transparent PNG files (4000×4000px, 300 DPI equivalent)
  PDF/ — 10 PDF files for print-ready use

HOW TO USE IN CRICUT DESIGN SPACE:
1. Unzip the file after download
2. Open Cricut Design Space → New Project → Upload
3. Select an SVG file → Upload as Cut Image
4. Resize, apply color, and cut!

HOW TO USE IN SILHOUETTE STUDIO:
1. File → Import → select any SVG file
2. Adjust size and cut settings

COMPATIBLE WITH:
★ Cricut (Joy, Explore, Maker — all models)
★ Silhouette (Cameo, Portrait, Curio)
★ Brother ScanNCut
★ Laser cutters (Glowforge, xTool, Atomstack)
★ Adobe Illustrator, Affinity Designer, Inkscape
★ Sublimation (use the transparent PNG files)

DESIGNS INCLUDED:
1. Class of 2026 — dot-ring circle badge with scroll & mortarboard
2. The Tassel Was Worth the Hassle — mortarboard with bold type
3. The Future Is Bright — sunburst with cap & 2026 center
4. Senior 2026 — jagged-edge badge seal
5. She Did It — burst circle with floral stars
6. Grad Mode: ON — bold hexagon badge
7. I Did It — dot ring with banner straps
8. Certificate of Graduation — diploma-style frame
9. Next Chapter — open book with ornament
10. Congrats Grad — pennant bunting with cap

LICENSE: Commercial use included.
You MAY sell finished physical items (shirts, tumblers, decals, etc.)
You MAY NOT resell, share, or redistribute the digital files.

© OnBrandCraftz
