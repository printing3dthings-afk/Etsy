SS1001 Vol 2 — America 250th Anniversary 3D Print Sign Pack (Designs 6–10)
OnBrandCraftz — Personal use + gifts only. Not for commercial printing/resale.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DESIGNS IN THIS VOLUME  (4-color: Cream + Navy + Red + Gold)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 6. America 250 Banner  — Rectangular banner, NAVY base, GOLD border/"AMERICA",
                          RED accent bands, CREAM "250" / dates
 7. America 250 Burst   — Sunburst / Art Deco disc, CREAM base, alternating
                          NAVY & RED sunburst rays, GOLD "AMERICA" / "250"
 8. America 250 Seal    — Circular medallion/seal, CREAM disc, NAVY ring + stars,
                          RED "AMERICA" rule lines, GOLD "250" / dates
 9. America 250 Shield  — Pentagon shield, NAVY base, GOLD "AMERICA" + eagle,
                          RED star band + "250"
10. America 250 Stamp   — Postage stamp silhouette, CREAM base, NAVY frame +
                          Liberty silhouette, RED "AMERICA" / "250", GOLD "FOREVER"

For designs 1–5 see the companion file: SS1001_america250_3dprint_pack_vol1.zip

━━━━━━━━━━━━━━━━━━
WHAT'S IN THIS ZIP
━━━━━━━━━━━━━━━━━━
5 design folders, each containing:
  • [design].3mf         — EASIEST: all 4 color layers pre-assembled, Z-heights set.
                           Open in Bambu Studio, assign AMS slots, slice, print.
  • layer01_base_[COLOR].svg  — Base plate (0–4 mm)
  • layer02_[COLOR].svg       — Raised design layer 1 (4–6 mm)
  • layer03_[COLOR].svg       — Raised design layer 2 (4–6 mm)
  • layer04_[COLOR].svg       — Raised design layer 3 (4–6 mm)

⚠️ These are 4-COLOR designs. You need a Bambu AMS (or manual filament swaps at 4 mm)
   to print all 4 colors. You can also simplify by loading only 2–3 layers.

━━━━━━━━━━━━━━━━━━
OPTION 1 — EASIEST: USE THE .3MF FILE
━━━━━━━━━━━━━━━━━━
1. Open Bambu Studio
2. File → Open → select [design].3mf
3. Four parts appear pre-positioned in the Objects panel
4. In the Filament list (left panel), click "+" to add each color needed:
     Cream / Off-White PLA  (base)
     Navy Blue PLA
     Deep Red PLA
     Gold / Antique Gold PLA
5. Click each part → assign to its filament in the Objects panel
6. Slice and print!

The layer filenames include the color name (CREAM / NAVY / RED / GOLD)
so it's easy to see which filament goes where.

━━━━━━━━━━━━━━━━━━
OPTION 2 — SVG LAYERS (for custom sizing or other slicers)
━━━━━━━━━━━━━━━━━━
1. In Bambu Studio, drag & drop layer01_base_[COLOR].svg → set height 4 mm
2. Right-click the model → Add Part → drag layer02 SVG → height 2 mm → Z-offset 4 mm
3. Repeat for layer03: height 2 mm, Z-offset 4 mm
4. Repeat for layer04: height 2 mm, Z-offset 4 mm
5. Add 4 colors in Filament list, assign one color per part
6. Use the Color Painting tool (press N) → Fill tool if any region needs correction
7. Slice and print!

Scale tip: select all parts (Ctrl+A) before scaling to keep them aligned.

━━━━━━━━━━━━━━━━━━
PRINTING TIPS
━━━━━━━━━━━━━━━━━━
• FLIP THE MODEL so the design face is DOWN on a textured PEI plate.
  In Bambu Studio: right-click → Place on Face → select the top face.
  This gives a perfectly smooth, layer-line-free front face.

• Recommended filaments:
    Cream / Off-White PLA for the base plate
    Navy Blue PLA for navy elements
    Deep Red PLA for red elements
    Gold Silk PLA for gold elements (Silk PLA gives a beautiful metallic sheen!)

• Layer height: 0.2 mm recommended.  Outer wall speed: 50 mm/s for best quality.

• No AMS? Print 1–2 colors only by omitting some layers, or use manual filament
  swaps at the 4 mm height change (the slicer will prompt you).

━━━━━━━━━━━━━━━━━━
SUPPORT
━━━━━━━━━━━━━━━━━━
Questions? Message us on Etsy: OnBrandCraftz
Printing3dthings@outlook.com

© OnBrandCraftz. Personal use + gifts only.
Not for resale, commercial printing, or redistribution.
