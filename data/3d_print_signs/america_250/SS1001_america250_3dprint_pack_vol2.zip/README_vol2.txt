SS1001 Vol 2 — America 250th Anniversary 3D Print Sign Pack (Designs 6–10)
OnBrandCraftz — Personal use + gifts only. Not for commercial printing/resale.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DESIGNS IN THIS VOLUME
━━━━━━━━━━━━━━━━━━━━━━
6. Flag Plaque     — American flag layout, "250 YEARS · AMERICA 1776–2026"
7. Medallion       — Circular "AMERICA · 250 · 1776–2026" with star ring
8. Freedom         — "LET FREEDOM RING" bold blue and red block layout
9. 4th of July     — "HAPPY 4TH OF JULY" in patriotic band layout
10. Shield         — Pentagon/shield shape, "AMERICA 250 · 1776–2026"

For designs 1–5 see the companion file: SS1001_america250_3dprint_pack_vol1.zip

━━━━━━━━━━━━━━━━━━
WHAT'S IN THIS ZIP
━━━━━━━━━━━━━━━━━━
5 design folders, each containing:
  • [design].3mf  — EASIEST: all color layers pre-assembled, Z-heights set.
                    Open in Bambu Studio, assign AMS slots, slice, print.
  • layer01_base_WHITE.svg  — White base plate  (prints at 4mm tall)
  • layer02_[COLOR].svg     — First design color  (prints at 2mm on top)
  • layer03_[COLOR].svg     — Second design color (prints at 2mm on top)

Note: Shield design has layer02_blue_BLUE + layer03_red_RED (reversed from other designs).
The .3mf handles this automatically — just assign White/Red/Blue to the correct parts.

━━━━━━━━━━━━━━━━━━
OPTION 1 — EASIEST: USE THE .3MF FILE
━━━━━━━━━━━━━━━━━━
1. Open Bambu Studio
2. File → Open → select [design].3mf
3. Three parts appear pre-positioned: base (0–4mm), color layer 1 (4–6mm), color layer 2 (4–6mm)
4. In the Filament list (left panel), click "+" to add 3 colors
5. Click each part in the Objects panel → assign to its filament color:
     base_WHITE → White or Cream PLA
     layer_RED  → Deep Red PLA
     layer_BLUE → Navy Blue PLA
6. Slice and print!

━━━━━━━━━━━━━━━━━━
OPTION 2 — SVG LAYERS (for custom sizing or other slicers)
━━━━━━━━━━━━━━━━━━
1. In Bambu Studio, drag & drop layer01_base_WHITE.svg → set height 4mm
2. Right-click the model → Add Part → drag the second layer SVG → set height 2mm
   → In Object panel, set Z-offset to 4mm (so it sits on top of the base)
3. Repeat for the third layer SVG: height 2mm, Z-offset 4mm
4. Add 3 colors in Filament list, assign one color per SVG part
5. Use the Color Painting tool (press N) if needed → Fill tool to refine regions
6. Slice and print!

Scale tip: select all 3 parts (Ctrl+A) before scaling to keep them aligned.

━━━━━━━━━━━━━━━━━━
PRINTING TIPS
━━━━━━━━━━━━━━━━━━
• FLIP THE MODEL so the design face is DOWN on a textured PEI plate.
  This gives a perfectly smooth, layer-line-free front face.
  In Bambu Studio: right-click → Place on Face → select the top face.

• Recommended filaments:
    White/Cream PLA for the base
    Deep Red PLA for the red layer
    Navy Blue PLA for the blue layer

• Layer height: 0.2mm recommended. Outer wall speed: 50mm/s for best quality.

• No AMS? Use filament swaps at layer 4mm (the slicer will prompt you).

━━━━━━━━━━━━━━━━━━
SUPPORT
━━━━━━━━━━━━━━━━━━
Questions? Message us on Etsy: OnBrandCraftz
Printing3dthings@outlook.com

© OnBrandCraftz. Personal use + gifts only.
Not for resale, commercial printing, or redistribution.
