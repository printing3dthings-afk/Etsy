OnBrandCraftz — America 250th Anniversary Sign SVG Pack
=======================================================
5 patriotic sign designs, each sized 250×250mm for direct import into Bambu Studio.

FILES INCLUDED:
  SS1001_america250_main.svg      — Bold eagle & 250 graphic  (navy/red/gold/cream)
  SS1001_america250_medallion.svg — Circular coin/seal design  (navy/gold/red/cream)
  SS1001_america250_artdeco.svg   — Art Deco sunburst           (navy/gold/red/cream)
  SS1001_america250_stamp.svg     — Vintage postage stamp       (red/navy/gold/parchment)
  SS1001_america250_shield.svg    — Heraldic crest/shield       (green/gold/red/cream)

HOW TO PRINT (Bambu Studio):
  1. File > Import > SVG → select any file
  2. Bambu Studio extrudes it automatically — set height to 6–10mm
  3. Right-click > Split > By Color → each color becomes a separate body
  4. Assign each body to an AMS slot (max 4 colors = 4 slots)
  5. Slice & print!

RECOMMENDED SETTINGS:
  Layer height: 0.2mm | Outer wall speed: 50mm/s | Infill: 15% gyroid
  Base layer height: 4mm | Color layer height: 2mm per color

FILAMENT SUGGESTIONS:
  Navy/Royal Blue PLA, Deep Red PLA, Gold Silk PLA, Cream/White PLA
  (or swap gold for Gold Silk PLA for a premium metallic finish)

SIZE & SCALING:
  Default: 250×250mm (~10×10 inches)
  To resize: scale uniformly in Bambu Studio before slicing

© OnBrandCraftz — Personal use only. Not for commercial resale.
Questions? Printing3dthings@outlook.com