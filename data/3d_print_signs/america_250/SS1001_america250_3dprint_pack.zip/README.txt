SS1001 — America 250th Anniversary 3D Print Sign Pack
OnBrandCraftz — Personal use + gifts only. Not for commercial printing/resale.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WHAT'S IN THIS ZIP
━━━━━━━━━━━━━━━━━━
5 design folders, each containing:
  • [design].3mf  — EASIEST: all color layers pre-assembled, Z-heights set.
                    Open in Bambu Studio, assign AMS slots, slice, print.
  • layer01_base_WHITE.svg  — White base plate  (prints at 4mm tall)
  • layer02_red_RED.svg     — Red elements       (prints at 2mm, sits on top of base)
  • layer03_blue_BLUE.svg   — Blue elements      (prints at 2mm, sits on top of base)

All signs default to ~165–220mm wide (fits Bambu 256mm plate with AMS prime tower).
Scale in Bambu Studio before slicing — SVGs are resolution-independent.

━━━━━━━━━━━━━━━━━━
OPTION 1 — EASIEST: USE THE .3MF FILE
━━━━━━━━━━━━━━━━━━
1. Open Bambu Studio
2. File → Open → select [design].3mf
3. Three parts appear pre-positioned: base (0–4mm), red layer (4–6mm), blue layer (4–6mm)
4. In the Filament list (left panel), click "+" to add 3 colors
5. Click each part in the Objects panel → assign to its filament color:
     base_WHITE → White or Cream PLA
     layer_RED  → Deep Red PLA
     layer_BLUE → Navy Blue PLA
6. Slice and print!

NOTE: Red and blue layers print at the same Z height (4–6mm) in different XY positions.
Bambu Studio handles this correctly — each color body prints in its own AMS turn.

━━━━━━━━━━━━━━━━━━
OPTION 2 — SVG LAYERS (for custom sizing or other slicers)
━━━━━━━━━━━━━━━━━━
1. In Bambu Studio, drag & drop layer01_base_WHITE.svg → set height 4mm
2. Right-click the model → Add Part → drag layer02_red_RED.svg → set height 2mm
   → In Object panel, set Z-offset to 4mm (so it sits on top of the base)
3. Repeat for layer03_blue_BLUE.svg: height 2mm, Z-offset 4mm
4. Add 3 colors in Filament list, assign one color per SVG part
5. Use the Color Painting tool (press N) if you want to adjust any region → Fill tool
6. Slice and print!

Scale tip: select all 3 parts (Ctrl+A) before scaling to keep them aligned.

━━━━━━━━━━━━━━━━━━
PRINTING TIPS
━━━━━━━━━━━━━━━━━━
• FLIP THE MODEL so the design face is DOWN on a textured PEI plate.
  This gives a perfectly smooth, layer-line-free front face.
  In Bambu Studio: right-click → Place on Face → select the top face.

• Recommended filaments:
    White/Cream PLA for the base
    Deep Red PLA for the red layer
    Navy Blue PLA for the blue layer (or any dark blue)
    OPTIONAL: Gold Silk PLA for the blue layer on the Star Badge design — stunning!

• Layer height: 0.2mm recommended. Outer wall speed: 50mm/s or lower for best quality.

• No AMS? Use filament swaps at layer 4mm (switch from white to your design colors).
  The slicer will prompt you to swap when the base is done.

━━━━━━━━━━━━━━━━━━
SUPPORT
━━━━━━━━━━━━━━━━━━
Questions? Message us on Etsy: OnBrandCraftz
Printing3dthings@outlook.com

© OnBrandCraftz. Personal use + gifts only.
Not for resale, commercial printing, or redistribution.
